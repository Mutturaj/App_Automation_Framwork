//
//  PPVerifiedKycHelper+PVWebDelegate.swift
//  KYC
//
//  Created by Naveengowda S Patil on 27/09/23.
//

import Foundation
import PPVerifiedSDK
import SBCommon
import PhonePeUI

extension PPVerifiedKycHelper: PVWebDelegate {
    
    func openHostAppScreen(_ screenName: String, screenData: [String : Any]) {
        KYCAnalyticsEventHandler.send(event: .BRIDGE_OPEN_NATIVE_SCREEN,
                                      eventData: ["screenName": screenName])
        guard let queryParams: ContactSupportParameters = try? JSONDecoder().decode(from: screenData) else {
            CommonSnackbarHelper.somethingWentWrong.showMessage()
            return
        }
        showContactSupport(queryParams: queryParams)
    }
    
    func didStartTokenRefresh(onSuccess: @escaping (String?) -> Void,
                              onFailure: @escaping (PPVerifiedSDK.PVWebGenericErrorResponse?) -> Void) {
        KYCAnalyticsEventHandler.send(event: .BRIDGE_REFRESH_TOKEN)
        getUpdatedSessionToken { sessionToken, error in
            if let sessionToken {
                onSuccess(sessionToken)
                KYCAnalyticsEventHandler.send(event: .BRIDGE_ON_TOKEN_REFRESHED)
            } else {
                onFailure(PVWebGenericErrorResponse(code: error?.code, message: error?.message))
                KYCAnalyticsEventHandler.send(event: .BRIDGE_TOKEN_REFRESH_FAILED)
            }
        }
    }
    
    func didReceiveAction(_ data: String?) {
        guard let messageData: KycPostMessageData = data?.getData() else {
            return
        }
        switch messageData.type {
        case .PAGE_VIEW:
            updateProgress()
        case .KYC_COMPLETED,
                .TERMINAL_ACTION:
            self.kycResponseHandler?.kycDidComplete()
            KYCAnalyticsEventHandler.send(event: .BRIDGE_TERMINATE_CALLED)
        case .ANALYTICS_EVENT:
            self.kycResponseHandler?.sendEvent(data: messageData.data)
        default:
            break
        }
    }
    
    func loaderView() -> PVWebLoaderable {
        getSBWebLoaderView()
    }
    
    func overlayLoaderView() -> PVWebOverlayLoaderable? {
        getSBWebLoaderView()
    }
    
    private func getSBWebLoaderView() -> SBWebLoaderView {
        let sbWebLoaderView = SBWebLoaderView()
        sbWebLoaderView.retryActionHandler = self
        return sbWebLoaderView
    }
    
    private func showContactSupport(queryParams: ContactSupportParameters) {
        if let vm = HelpWebViewModel(mode: .contactSupport(queryParams: queryParams), navigationBackAction: { [weak self] in
            self?.pvNavigationController?.dismiss(animated: true)
        }) {
            let view = HelpWebView(viewModel: vm)
            let helpVc = BaseHostingViewController(rootView: view)
            helpVc.modalPresentationStyle = .overFullScreen
            self.pvNavigationController?.present(helpVc, animated: true)
        }
    }
    
    private func getUpdatedSessionToken(completionHandler: @escaping (_ sessionToken: String?,
                                                                      _ error: KycWorkFlowRequestError?) -> Void) {
        callWorkflowInit { response, error in
            guard let sessionToken = response?.sessionToken else {
                completionHandler(nil, error)
                return
            }
            completionHandler(sessionToken, nil)
        }
    }
}

extension PPVerifiedKycHelper {
    // MARK: Private Models
    private struct KycPostMessageData: Decodable {
        let type: KycPostMessageDataType?
        let section: String?
        let data: [String: Any]?
        
        enum CodingKeys: CodingKey {
            case type
            case section
            case data
        }
        
        init(from decoder: Decoder) throws {
            let container: KeyedDecodingContainer<CodingKeys> = try decoder.container(keyedBy: CodingKeys.self)
            self.type = try container.decodeIfPresent(KycPostMessageDataType.self, forKey: CodingKeys.type)
            self.section = try container.decodeIfPresent(String.self, forKey: CodingKeys.section)
            self.data = try container.decodeIfPresent([String: Any].self, forKey: CodingKeys.data)
        }
        
        enum KycPostMessageDataType: String, Codable {
            case SUBMIT_TRIGGERED
            case SUBMIT_COMPLETED
            case TERMINAL_ACTION
            case PAGE_VIEW
            case KYC_POLLING_TIMEOUT
            case KYC_COMPLETED
            case SUBMIT_FAILED
            case ANALYTICS_EVENT
        }
    }
}
