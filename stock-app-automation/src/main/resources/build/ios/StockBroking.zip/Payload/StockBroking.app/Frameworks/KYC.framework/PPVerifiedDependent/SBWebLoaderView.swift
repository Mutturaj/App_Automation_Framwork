//
//  SBWebLoaderView.swift
//  KYC
//
//  Created by Naveengowda S Patil on 16/07/23.
//

import PPVerifiedSDK
import PhonePeUI
import SwiftUI
import CommonCodeUtility

class SBWebLoaderView: UIView, PVWebLoaderable, PVWebOverlayLoaderable {
    private var loaderVc: UIViewController?
    weak var retryActionHandler: RetryActionHandler?
    
    func showRetryView(retryAction: @escaping EmptyCompletion) {
        retryActionHandler?.showRetryView(retryAction: retryAction)
    }
    
    func show(parentVController: UIViewController) {
        guard let loader = self.loaderVc else {
            let childVc = UIHostingController(rootView: ApeLoadingView().frame(width: 32, height: 32))
            parentVController.addChild(childVc)
            self.loaderVc = childVc
            show(parentVController: parentVController)
            return
        }
        parentVController.view.addSubview(loader.view)
        loader.didMove(toParent: parentVController)
        loader.view.ppe_enableAutolayout()
            .ppe_center(in: parentVController.view)
            .ppe_setWidthConstraint(50)
            .ppe_setWidhtEqualToHeight()
    }
    
    func hide() {
        loaderVc?.willMove(toParent: nil)
        loaderVc?.view.removeFromSuperview()
        loaderVc?.removeFromParent()
        loaderVc = nil
    }
}

struct SBColorProvider: PVWebColorProviderProtocol {
    func getColor(for type: PVWebColor) -> UIColor {
        switch type {
        case .brand:
            return ApeTheme.current.colorPallete.iconColors.brandPrimary.uiColor
        case .dark:
            return ApeTheme.current.colorPallete.textColors.primary.uiColor
        case .white:
            return ApeTheme.current.colorPallete.backgroundColors.liteDefault.uiColor
        }
    }
}
