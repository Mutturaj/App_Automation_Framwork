//
//  PPVerifiedKycHelper.swift
//  KYC
//
//  Created by Naveengowda S Patil on 16/06/23.
//

import Foundation
import SBCommon
import CommonCodeUtility
import PPVerifiedSDK
import SwiftUI
import Combine
import SBResources
import PhonePeUI
import WebKit
import NetworkClient

final class PPVerifiedKycHelper: KYCHelper {
    private var subscriptions: [Combine.AnyCancellable] = []
    private var workflowInitSubscription: Combine.AnyCancellable?
    private var currentPvStep: PVStep?
    
    private let manager = PVWebManager()
    private let kycRepository: KycRepositoryProtocol
    private let navbarHeight: CGFloat = 56
    
    private weak var coordinator: (Coordinator & ApeDialogDismissable)?
    private weak var noInternetVc: UIViewController?
    
    weak var pvNavigationController: UINavigationController?
    
    private lazy var navigationViewModel = {
        PvNavigationViewModel(helpButtonAction: { [weak self] helpTag in
            self?.helpAction(tag: helpTag)
        }, closeButtonAction: { [weak self] in
            self?.closeAction()
        })
    }()
    
    init(kycRepository: KycRepositoryProtocol,
         coordinator: Coordinator & ApeDialogDismissable) {
        self.kycRepository = kycRepository
        self.coordinator = coordinator
        super.init(navigationController: coordinator.navigationController)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(reachabilityChanged),
                                               name: .reachabilityChanged,
                                               object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override func startKyc(kycWorkFlowGenerateResponse: KycWorkFlowGenerateResponse, kycResponseHandler: KycResponseHandlerInterface) {
        self.kycResponseHandler = kycResponseHandler
        startPVKycBuilder(kycWorkFlowGenerateResponse: kycWorkFlowGenerateResponse)
    }
    
    func updateProgress() {
        self.kycRepository.getPVNavigationBarData()
            .receive(on: DispatchQueue.main)
            .sink { completion in
                switch completion {
                case .failure:
                    KYCAnalyticsEventHandler.send(event: .STEPS_API_FAILED)
                    CommonSnackbarHelper.customMessage(R.string.localizable.failedFetchingKycProgress()).showMessage()
                default:
                    break
                }
            } receiveValue: { [weak self] pvNavBarData in
                guard let self else {
                    return
                }
                self.navigationViewModel.update(with: pvNavBarData)
            }
            .store(in: &subscriptions)
    }
    
    func callWorkflowInit(completionHandler: @escaping (_ response: KycWorkFlowGenerateResponse?,
                                                        _ error: KycWorkFlowRequestError?) -> Void) {
        guard workflowInitSubscription.isNil else { return }
        
        workflowInitSubscription = kycRepository.workflowInit()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] completion in
                switch completion {
                case .failure(let error):
                    completionHandler(nil, error)
                default:
                    break
                }
                self?.workflowInitSubscription = nil
            } receiveValue: { response in
                completionHandler(response, nil)
            }
    }
    
    private func startPVKycBuilder(kycWorkFlowGenerateResponse: KycWorkFlowGenerateResponse) {
        guard let pvWebURLDetail = getPVWebURLDetail(from: kycWorkFlowGenerateResponse) else {
            CommonSnackbarHelper.somethingWentWrong.showMessage()
            return
        }
        
        let config = PVWebConfigModel(urlDetail: pvWebURLDetail,
                                      refreshAllowed: false,
                                      colorProvider: SBColorProvider(),
                                      analyticsProvider: self)
        DispatchQueue.main.async {
            self.manager.start(config: config, delegate: self) { [weak self] pvViewController in
                KYCAnalyticsEventHandler.send(event: .PV_INITIALISED)
                guard let self else {
                    return
                }
                let viewController = self.addNavigationView(to: pvViewController)
                let nav = UINavigationController()
                nav.viewControllers = [viewController]
                nav.modalPresentationStyle = .overFullScreen
                nav.navigationBar.isHidden = true
                self.updateProgress()
                self.navigationController?.presentOnTopVc(nav, animated: false) {
                    KYCAnalyticsEventHandler.send(event: .SCREEN_LOADED)
                    self.pvNavigationController = nav
                }
            }
        }
    }
    
    /// Adds `PvNavigationView` at the top, which shows progess of KYC.
    private func addNavigationView(to pvViewController: UIViewController) -> UIViewController {
        let viewController = UIViewController()
        let topView: UIView = UIView()
        guard let superView = viewController.view, let pvVCView = pvViewController.view else {
            return pvViewController
        }
        
        let navHostingVc = UIHostingController(rootView: PvNavigationView(viewModel: navigationViewModel))
        
        viewController.addChild(navHostingVc)
        navHostingVc.didMove(toParent: viewController)
        
        viewController.addChild(pvViewController)
        pvViewController.didMove(toParent: viewController)
        KYCAnalyticsEventHandler.send(event: .PV_FRAGMENT_ATTACHED)
        
        topView.addSubview(navHostingVc.view)
        navHostingVc.view.ppe_enableAutolayout()
            .ppe_pinSides(topView)
            .ppe_bottom(in: topView)
            .ppe_top(toTopOf: topView)
        
        superView.addSubview(pvVCView)
        superView.addSubview(topView)
        topView.ppe_enableAutolayout()
            .ppe_setHeightConstraint(navbarHeight)
        topView.backgroundColor = ApeTheme.current.colorPallete.backgroundColors.liteDefault.uiColor
        topView.ppe_pinSides(superView)
            .ppe_top(in: superView, topLayoutMargin: true)
        
        pvVCView.ppe_enableAutolayout()
            .ppe_pinSides(superView)
            .ppe_bottom(in: superView)
            .ppe_top(toBottomOf: topView)
        
        return viewController
    }
    
    private func showNoConnectionView() {
        guard let parentVC = self.pvNavigationController?.children.first,
              self.noInternetVc.isNil else {
            return
        }
        let buttonVM = ApeV2ButtonViewModel(title: R.string.localizable.retry(),
                                            state: .normal,
                                            style: .primary(.brandPrimary),
                                            size: .regular,
                                            action: { [weak self] in
            self?.callWorkflowInitIfReachable()
        })
        let view = NoInternetView(retryButtonVM: buttonVM)
        let navHostingVc = UIHostingController(rootView: view)
        
        parentVC.addChild(navHostingVc)
        navHostingVc.didMove(toParent: parentVC)
        parentVC.view.addSubview(navHostingVc.view)
        navHostingVc.view.ppe_enableAutolayout()
            .ppe_pinSides(parentVC.view)
            .ppe_bottom(in: parentVC.view)
            .ppe_pinSafeTop(parentVC.view, constant: navbarHeight + 2)
        parentVC.view.bringSubviewToFront(navHostingVc.view)
        self.noInternetVc = navHostingVc
    }
    
    private func callWorkflowInitIfReachable() {
        if let connection = PPNetworkConnectionHandler.shared.reachability?.connection,
           connection != .unavailable,
           workflowInitSubscription.isNil {
            
            removeRetryView()
            showLoadingView()
            callWorkflowInit { [weak self] response, _ in
                guard let self else {
                    return
                }
                self.coordinator?.dismissApeDialog()
                if let response,
                   let pvWebURLDetail = self.getPVWebURLDetail(from: response) {
                    self.manager.reload(urlDetail: pvWebURLDetail)
                    KYCAnalyticsEventHandler.send(event: .RETRY_FLOW_TRIGGERED)
                } else {
                    self.showNoConnectionView()
                }
            }
        }
    }
    
    private func removeRetryView() {
        noInternetVc?.willMove(toParent: nil)
        noInternetVc?.view.removeFromSuperview()
        noInternetVc?.removeFromParent()
    }
    
    private func showLoadingView() {
        guard let coordinator else {
            return
        }
        let dialogVM = ApeDialog.ViewModel(title: SBResources.R.string.localizable.loadingPleaseWait(),
                                           isLoading: true,
                                           dismissCoordinatorable: coordinator)
        coordinator.showApeDialog(viewModel: dialogVM)
    }
    
    private func getPVWebURLDetail(from response: KycWorkFlowGenerateResponse) -> PVWebURLDetail? {
        guard let sessionToken = response.sessionToken else {
            return nil
        }
        let intent = response.intent.or(PvConfigurationConstants.intent)
        let tenantName = response.tenantName.or(PvConfigurationConstants.tenantName)
        
        return PVWebURLDetail(intent: intent,
                              tenantName: tenantName,
                              token: sessionToken)
    }
    
    private func helpAction(tag: String) {
        if let vm = HelpWebViewModel(mode: getHelpMode(tag),
                                     navigationBackAction: { [weak self] in
            self?.pvNavigationController?.dismiss(animated: true)
        }) {
            let view = HelpWebView(viewModel: vm)
            let helpVc = BaseHostingViewController(rootView: view)
            helpVc.modalPresentationStyle = .overFullScreen
            self.pvNavigationController?.present(helpVc, animated: true)
        }
    }
    
    private func getHelpMode(_ tag: String) -> HelpWebViewModel.Mode {
        .deeplinkFaq(category: HelpURLGenerator.HelpCategory.onboarding.rawValue,
                     tag: tag,
                     queryParams: .init(source: "onboarding"))
    }
    
    private func closeAction() {
        let exitAccOpening = ApeDialogButton.ViewModel(title: SBResources.R.string.localizable.exitAccOpening(),
                                                       action: { [weak self] in
            self?.pvNavigationController?.dismissTopVC() {
                WKWebsiteDataStore.clear()
                KYCAnalyticsEventHandler.send(event: .CLEAR_WEB_VIEW_HISTORY)
                self?.kycResponseHandler?.kycFlowCancelledByUser()
            }
        })
        
        let continueApplication = ApeDialogButton.ViewModel(title: SBResources.R.string.localizable.continueApplication(),
                                                            action: { [weak self] in
            self?.pvNavigationController?.dismissTopVC()
        })
        
        let viewModel = ApeDialog.ViewModel(alignment: .vertical,
                                            position: .center,
                                            image: nil,
                                            title: R.string.localizable.exitAccountOpeningTitle(),
                                            description: R.string.localizable.exitAccountOpeningMessage(),
                                            primaryButton: exitAccOpening,
                                            secondaryButton: continueApplication)
        
        self.navigationController?.present(view: ApeDialog(viewModel),
                                           presentationStyle: .overFullScreen,
                                           transitionStyle: .crossDissolve,
                                           backgroundColor: .clear,
                                           completion: nil)
    }
    
    @objc private func reachabilityChanged(_ note: Notification) {
        if let reachability = note.object as? Reachability {
            Thread.performOnMainThread {
                if reachability.connection == .unavailable {
                    self.showNoConnectionView()
                } else {
                    self.callWorkflowInitIfReachable()
                }
            }
        }
    }
}

extension PPVerifiedKycHelper: RetryActionHandler {
    func showRetryView(retryAction: @escaping EmptyCompletion) {
        let exitAction = UIAlertAction(title: SBResources.R.string.localizable.exit().capitalized,
                                       style: .destructive) { [weak self] _ in
            self?.kycResponseHandler?.kycFlowCancelledByUser()
        }
        
        let retryAlertAction = UIAlertAction(title: SBResources.R.string.localizable.retry().capitalized,
                                             style: .default) { _ in
            retryAction()
        }
        let alertVC = UIAlertController(title: SBResources.R.string.localizable.somethingWrongTryAgain(),
                                        message: nil,
                                        preferredStyle: .alert)
        alertVC.addAction(exitAction)
        alertVC.addAction(retryAlertAction)
        navigationController?.presentOnTopVc(alertVC, animated: true)
    }
}

extension PPVerifiedKycHelper: PVAnalyticsProviderProtocol {
    func sendEventFor(_ eventName: String, analyticsInfo: PVAnalyticsInfo?) {
        KYCAnalyticsEventHandler.sendLegacyEvent(event: eventName, eventData: analyticsInfo?.eventData)
    }
}

protocol RetryActionHandler: AnyObject {
    func showRetryView(retryAction: @escaping EmptyCompletion)
}
